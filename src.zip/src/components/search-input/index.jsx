

const SearchInput = () =>{
    let numb;
  return (
    <div className="search-box">
           
     <input className="serch-box" type="search" placeholder="search Monsters"/>
     <button> 🚀 </button>
            
    </div>
  )
   console.log(numb);
}

export default SearchInput;