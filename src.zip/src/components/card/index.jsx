import "./index.css"

export const Card = (props) => {
  const{monsterdata}=props;
  const{id,name,email,phone,address}=monsterdata;
 
    const url="https://robohash.org/"+id+"?set=set2&size=180x180";
    return(
<div className="card-container">
    <img src={url} alt="monster-image"/>
    <h2> {name}</h2>
    <h3>{email}</h3>
    <h3>{phone}</h3>
    <p>{address.street}</p>
</div>

)}