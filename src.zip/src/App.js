
import { Component } from "react"
import "./App.css"
import SearchInput from "./components/search-input"
import { CardList } from "./components/card-list"

   
  
class App extends Component{
    constructor(props){
        super(props)
      this.x=100
        this.state = {
            data: 12
          }

    }
     
   componentDidMount(){
    setTimeout(()=>{this.setState({
        data: 100
      })
    },3000)
  }

  render(){
    return (
        
        <div className="App">
        <h1>Monster App</h1>
           <SearchInput/>
          
           <CardList/>
            </div>

    );
  }
}

export default App;


   

